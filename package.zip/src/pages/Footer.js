import React from "react";

function Footer() {
  return (
    <footer>
      <p>Made in 🇮🇳 | © 2025 Secure Voting System</p>
    </footer>
  );
}

export default Footer;
