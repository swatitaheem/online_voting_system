import React, { useState } from 'react';
import axios from 'axios';
import { Container, Row, Col, Card, Button, Form } from 'react-bootstrap';
import { toast } from 'react-toastify';

const parties = [
  {
    id: 'bjp',
    name: 'Bharatiya Janata Party (BJP)',
    work: 'Digital India, Ujjwala Yojana, Make in India',
  },
  {
    id: 'inc',
    name: 'Indian National Congress (INC)',
    work: 'RTI Act, MNREGA, National Food Security Act',
  },
  {
    id: 'aap',
    name: 'Aam Aadmi Party (AAP)',
    work: 'Free electricity, Education reform',
  },
  {
    id: 'sp',
    name: 'Bahujan Samaj Party (BSP)',
    work: 'Rural development, Infrastructure',
  },
];

export default function Vote() {
  const [aadhaar, setAadhaar] = useState('');
  const [name, setName] = useState('');
  const [selectedParty, setSelectedParty] = useState(null);  // Change from '' to null

  const handleVote = async () => {
    try {
      if (!aadhaar || !selectedParty) {
        toast.error('Please fill all required fields');
        return;
      }
      if (!/^\d{12}$/.test(aadhaar)) {
        toast.error('Please enter a valid 12-digit Aadhaar number');
        return;
      }
  
      const response = await axios.post('http://localhost:5000/vote', {
        aadhaar: aadhaar,
        party: selectedParty.id 
      }, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
  
      if (response.data.success) {
        toast.success('Vote recorded successfully!');
        // Clear form
        setAadhaar('');
        setSelectedParty(null);
        setName('');
      }
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Error submitting vote';
      toast.error(errorMessage);
      console.error('Voting error:', error.response?.data);
    }
  };

  return (
    <Container className="mt-5">
      <h2 className="text-center mb-4">Indian Political Voting System</h2>

      <Card className="p-4 mb-5 shadow">
        <Form>
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>Aadhaar Number</Form.Label>
                <Form.Control
                  type="text"
                  value={aadhaar}
                  onChange={(e) => setAadhaar(e.target.value)}
                  placeholder="Enter your Aadhaar"
                />
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>Full Name</Form.Label>
                <Form.Control
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your name"
                />
              </Form.Group>
            </Col>
          </Row>
        </Form>
      </Card>

      <Row>
        {parties.map((party, idx) => (
          <Col md={6} lg={4} className="mb-4" key={idx}>
            <Card
              className={`h-100 ${
                selectedParty === party.name ? 'border-success border-2' : ''
              }`}
            >
              <Card.Body>
                <Card.Title>{party.name}</Card.Title>
                <Card.Text>{party.work}</Card.Text>
                <Button
                  variant={
                    selectedParty === party.name ? 'success' : 'outline-success'
                  }
                  onClick={() => setSelectedParty(party)}
                >
                  {selectedParty === party.name ? 'Selected' : 'Select'}
                </Button>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>

      <div className="text-center mt-4">
        <Button
          variant="primary"
          size="lg"
          onClick={handleVote}
          disabled={!selectedParty}
        >
          Submit Vote
        </Button>
      </div>
    </Container>
  );
}
