import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Container, Table } from 'react-bootstrap';
import { toast } from 'react-toastify';

export default function AdminPanel() {
  const [votes, setVotes] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('http://localhost:5000/results')
      .then((response) => {
        if (response.data.success) {
          setVotes(response.data.data.votes);
        } else {
          toast.error('Failed to load results');
        }
      })
      .catch((error) => {
        console.error('Error loading results:', error);
        toast.error('Error loading election results');
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <Container className="mt-5 text-center">Loading results...</Container>;
  }

  return (
    <Container className="mt-5">
      <h3 className="text-center mb-4">Election Results</h3>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>#</th>
            <th>Party</th>
            <th>Votes</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(votes).map(([party, count], index) => (
            <tr key={party}>
              <td>{index + 1}</td>
              <td>{party}</td>
              <td>{count}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Container>
  );
}

